﻿using System.ComponentModel.DataAnnotations.Schema;

namespace AppConcurso.Models
{
  [Table("inscricao")]
        public class Inscricao
       {
            [Column("id")]
            public int Id { get; set; }
            [Column("numero_insc")]
            public int NumeroInsc { get; set; }
            [Column("data_inscricao")]
            public DateTime DataInscricao { get; set; }
            [Column("nota_conh_gerais")]
            public decimal? NotaConhecimentoGerais { get; set; }
            [Column("nota_conh_especificos")]
            public decimal? NotaConhecimentoEspecificos { get; set; }

            [Column("candidato_id")]
            public int IdCandidato { get; set; }

            [ForeignKey("IdCandidato")] //Informa qual o atributo da classe vai armazenar a FK
            public Candidato? Candidato { get; set; } //Indica o dono da propiedade

            [Column("cargo_id")]
            public int IdCargo { get; set; }

            [ForeignKey("IdCargo")] //Informa qual o atributo da classe vai armazenar a FK
            public Cargo? Cargo { get; set; } //Indica o dono da propiedade
        }
}
